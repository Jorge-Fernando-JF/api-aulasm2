const tecnicos = [
    {
        nome: "João Silva",
        especialidade:"redes"
    },
    {
        nome: "Maria Santos",
        especialidade:"software"
    },
    {
        nome: "Carlos Lima",
        especialidade:"hardware"
    }

]
function buscaPorEspecialidade(especialidade){
    return tecnicos.find();
}